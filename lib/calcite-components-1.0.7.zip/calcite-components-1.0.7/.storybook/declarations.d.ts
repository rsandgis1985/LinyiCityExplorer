// file imports
declare module "*.json";
declare module "*.md";
declare module "*.svg";
