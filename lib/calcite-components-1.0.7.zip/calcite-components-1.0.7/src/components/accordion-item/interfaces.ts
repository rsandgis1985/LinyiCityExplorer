export interface RegistryEntry {
  parent: HTMLCalciteAccordionElement;
  position: number;
}

export interface RequestedItem {
  requestedAccordionItem: HTMLCalciteAccordionItemElement;
}
