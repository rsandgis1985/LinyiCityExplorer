export const SLOTS = {
  menuActions: "menu-actions",
  menuTooltip: "menu-tooltip"
};

export const ICONS = {
  menu: "ellipsis"
};
