export type BlockSectionToggleDisplay = "button" | "switch";
