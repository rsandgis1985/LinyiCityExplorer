# calcite-avatar

The avatar component provides a unique (but consistent) visual for a user. It's built
to work with users returned from the ArcGIS REST API.

<!-- Auto Generated Below -->

## Usage

### Basic

The JSON sample user below is returned from a [search for users](https://developers.arcgis.com/rest/users-groups-and-items/user-search.htm). You can create an avatar for Ron by passing these properties directly to the avatar component.

When no thumbnail is provided, the avatar component will construct a useful placeholder, leveraging the user's information to construct a unique background-color with initials.

**Note:** if your user is private, remember to append a token to the end of the thumbnail using the form `thumbnail.jpg?token=YOUR_LOGGED_IN_USER_TOKEN`.

```json
{
  "username": "ron_swanson_pawnee",
  "id": "a81470986eaeee1833b74b7d8abcd5b2",
  "fullName": "Ron Swanson",
  "firstName": "Ron",
  "lastName": "Swanson",
  "thumbnail": "mySelf.jpg",
  ...
}
```

```html
<calcite-avatar
  username="ron_swanson_pawnee"
  user-id="a81470986eaeee1833b74b7d8abcd5b2"
  full-name="Ron Swanson"
  thumbnail="mySelf.jpg"
>
</calcite-avatar>
```

## Properties

| Property    | Attribute   | Description                                                                       | Type                | Default     |
| ----------- | ----------- | --------------------------------------------------------------------------------- | ------------------- | ----------- |
| `fullName`  | `full-name` | Specifies the full name of the user.                                              | `string`            | `undefined` |
| `scale`     | `scale`     | Specifies the size of the component.                                              | `"l" \| "m" \| "s"` | `"m"`       |
| `thumbnail` | `thumbnail` | Specifies the `src` to an image (remember to add a token if the user is private). | `string`            | `undefined` |
| `userId`    | `user-id`   | Specifies the unique id of the user.                                              | `string`            | `undefined` |
| `username`  | `username`  | Specifies the username of the user.                                               | `string`            | `undefined` |

## Dependencies

### Depends on

- [calcite-icon](../icon)

### Graph

```mermaid
graph TD;
  calcite-avatar --> calcite-icon
  style calcite-avatar fill:#f9f,stroke:#333,stroke-width:4px
```

---

_Built with [StencilJS](https://stenciljs.com/)_
