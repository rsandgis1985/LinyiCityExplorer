Renders a header and control with a slot for adding a single HTML element (in the header).

```html
<calcite-block heading="This header" description="it has an input">
  <calcite-action icon="pencil" text="edit" slot="control"></calcite-action>
</calcite-block>
```
