Renders a basic, non-collapsible block.

```html
<calcite-block heading="Fruit" description="It's nature's candy"> </calcite-block>
```
