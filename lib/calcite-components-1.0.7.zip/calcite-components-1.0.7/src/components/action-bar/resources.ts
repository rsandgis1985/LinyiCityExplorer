export const CSS = {
  actionGroupBottom: "action-group--bottom"
};

export const SLOTS = {
  bottomActions: "bottom-actions",
  expandTooltip: "expand-tooltip"
};
