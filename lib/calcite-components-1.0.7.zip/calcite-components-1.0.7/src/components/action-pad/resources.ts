export const CSS = {
  actionGroupBottom: "action-group--bottom",
  container: "container"
};

export const SLOTS = {
  expandTooltip: "expand-tooltip"
};
