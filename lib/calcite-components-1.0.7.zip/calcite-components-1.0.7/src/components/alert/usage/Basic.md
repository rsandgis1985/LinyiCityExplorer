A single instance of an alert. Multiple alerts will aggregate in a queue.

```html
<calcite-alert open>
  <div slot="title">Title of alert</div>
  <div slot="message">Message text of the alert</div>
  <a slot="link" href="#">Retry</a>
</calcite-alert>
```
