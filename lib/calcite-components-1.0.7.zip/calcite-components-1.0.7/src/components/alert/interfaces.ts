export type AlertDuration = "fast" | "medium" | "slow";
export interface Sync {
  queue: HTMLCalciteAlertElement[];
}
