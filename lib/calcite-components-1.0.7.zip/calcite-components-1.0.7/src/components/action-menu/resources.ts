export const CSS = {
  menu: "menu",
  defaultTrigger: "default-trigger"
};

export const SLOTS = {
  tooltip: "tooltip",
  trigger: "trigger"
};

export const ICONS = {
  menu: "ellipsis"
};
