Renders a `calcite-action` that is transparent.

```html
<calcite-action appearance="transparent" text="Layers" icon="layers"></calcite-action>
```
