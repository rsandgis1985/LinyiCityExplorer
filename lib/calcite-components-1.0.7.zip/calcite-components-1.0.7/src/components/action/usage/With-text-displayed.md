Renders a `calcite-action` that displays text alongside an icon.

```html
<calcite-action label="Performs my custom action" text="Perform Action!" text-enabled icon="save"></calcite-action>
```
