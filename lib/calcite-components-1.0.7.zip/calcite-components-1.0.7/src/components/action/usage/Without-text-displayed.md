Renders a `calcite-action` that displays only an icon.

```html
<calcite-action label="Performs my custom action" text="My Custom Action" icon="plus"></calcite-action>
```
