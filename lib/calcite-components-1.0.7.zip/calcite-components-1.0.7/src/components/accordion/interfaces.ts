export interface RequestedItem {
  requestedAccordionItem: HTMLCalciteAccordionItemElement;
}
