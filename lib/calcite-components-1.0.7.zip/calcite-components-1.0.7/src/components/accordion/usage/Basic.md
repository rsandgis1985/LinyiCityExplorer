```html
<calcite-accordion>
  <calcite-accordion-item heading="Accordion Item">Accordion Section Content </calcite-accordion-item>
  <calcite-accordion-item heading="Accordion Item 2" expanded>Accordion Section Content </calcite-accordion-item>
  <calcite-accordion-item heading="Accordion Item 3">Accordion Section Content </calcite-accordion-item>
</calcite-accordion>
```
